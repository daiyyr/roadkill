/// <reference path="filemanager.references.ts" />
//# sourceMappingURL=directoryviewmodel.js.map