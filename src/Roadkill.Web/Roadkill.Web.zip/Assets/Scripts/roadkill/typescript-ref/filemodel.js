/// <reference path="filemanager.references.ts" />
//# sourceMappingURL=filemodel.js.map