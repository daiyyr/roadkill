declare var $ : any;
declare var toastr : any;
declare var bootbox : any;

//
// All variables below are copied from InstallerJsVars
// and defined here to help Typescript compilation out.
//

declare var ROADKILL_INSTALLER_WOOPS;
declare var ROADKILL_INSTALLER_TESTWEBCONFIG_URL;
declare var ROADKILL_INSTALLER_TESTDATABASE_URL;
declare var ROADKILL_INSTALLER_COPYSQLITE_URL;
declare var ROADKILL_INSTALLER_TESTLDAP_URL;
declare var ROADKILL_INSTALLER_TESTATTACHMENTS_URL;